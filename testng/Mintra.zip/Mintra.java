package testng;

/*import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Mintra {
	WebDriver driver;
	String parentWinId;


	@Test
	public void When_guesr_user_open_mintra(){

		// Disable notifications coming from browser
		ChromeOptions options = new ChromeOptions() ;
		options.addArguments("disable-notifications");


		System.setProperty("webdriver.chrome.driver", ".//lib//chromedriver.exe");
		driver =new ChromeDriver(options);

		driver.manage().window().maximize();

		driver.get("https://www.myntra.com/");
		parentWinId = driver.getWindowHandle();
	}

	@Test(dependsOnMethods="When_guest_user_open_mintra")
	public void then_search_girl_watches() {

		driver.findElement(By.xpath("//input[@class='desktop-searchBar']")).sendKeys("Girl Watchs",Keys.ENTER);

	}

	@Test(dependsOnMethods="then_search_watch_girls")
	public void Then_click_WISHLIST() {
		Set<String> allWin=driver.getWindowHandles();
		for(String win: allWin)
		{
			if(!win.equals(parentWinId))
			{
				driver.switchTo().window(win);
			}
		}

		driver.findElement(By.xpath("//*[@id=\"desktopSearchResults\"]/div[2]/section/ul/li[2]/div[4]/span/span")).click();
	}


	@Test(dependsOnMethods="Then_click_WISHLIST")
	public void  click_checkoutprocess() throws InterruptedException{
		Thread.sleep(8000);
		driver.close();
	}



}*/

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import org.testng.annotations.Test;

public class Mintra {
	WebDriver driver;
	String parentWinId;
	ChromeOptions options;


  @Test
  public void When_guesr_user_open_mintra(){

	  System.setProperty("webdriver.chrome.driver", ".//lib//chromedriver.exe");

	 options = new ChromeOptions();
	  options.addArguments("disable-notifications");
	  driver =new ChromeDriver(options);

	  driver.get("https://www.myntra.com/");
	  parentWinId = driver.getWindowHandle();
  }

  @Test(dependsOnMethods="When_guesr_user_open_mintra")
  public void then_search_mobile_cover() {
	  driver.findElement(By.xpath("//input[@class='desktop-searchBar']")).sendKeys("mobile cover",Keys.ENTER);
	  
 }
  @Test(dependsOnMethods="then_search_mobile_cover")
  public void then_click__product() {
	  driver.findElement(By.xpath("//*[@class=\"product-sliderContainer\"]")).click();
  }
  
  @Test(dependsOnMethods="then_click_product ")
	public void Then_click_WISHLIST() {
	Set<String> allWin =	driver.getWindowHandles();
	for(String win : allWin) {
		if(!win.equals(parentWinId))
		{
		  driver.switchTo().window(win);
		}
	  }
	
	try {
  
		WebElement wishlist=driver.findElement(By.xpath("//span[contains(text(),'WISHLIST')]")).click();
	    if(wishlist.isDisplayed()){
	    	wishlist.click();
	    }
		
	}catch(Exception e)
	{
		System.out.println(e.getMessage());
	}
}
  @Test(dependsOnMethods="Then_click_WISHLIST") 
  public void click_ckeckoutprocess() {
	driver.close();

  }

}
 